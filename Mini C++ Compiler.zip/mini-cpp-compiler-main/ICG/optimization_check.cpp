int main()
{
	int a = 4*5;
}