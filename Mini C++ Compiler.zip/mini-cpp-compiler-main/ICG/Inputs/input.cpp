int main()
{

    int c = 2;
    int f = 4;
    int d = 4;
    int e = 5;
    int b = 4;
    int a = 3;
    if(a < b)
    {
        int a = 4;
        int b = 6;
        a = b;
	}
    else if(1+3)
    {
        2 + 3;
    }
    else
    {
        int a = 4;
        int a = a + 4;
    }
	while (c)
	{
		a = b + c;
	}
    int i = 0;
    for (i = 5;i < 10;i += 1)
    {
        c = d + 10;
	if(a < b)
    {
        int a = 4;
        int b = 6;
        a = b;
	}
    }
	
}
