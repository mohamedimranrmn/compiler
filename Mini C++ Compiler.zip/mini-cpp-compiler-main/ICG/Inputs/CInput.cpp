int main()
{
    int a = 3;
    int b = 5 + a;
    int c = a + b;
    int d = c * e;
    int a = 8;
    int f = 2 * a;
    if (x)
    a = a + e;
    
}
