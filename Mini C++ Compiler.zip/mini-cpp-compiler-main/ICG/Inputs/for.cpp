int main()
{
    for (int i = 5;i < 10;i = i + 1)
    {
        c = d + 10;
    }
}