int main()
{
    int a = 4;
    for(int i = 1; i < 10; i = i + 1)
    {
        int b = 6;
    }
}