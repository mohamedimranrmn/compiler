int main(){
	/*
		Random Comment
	*/

    int x = 5;
    int p = 1;
    
    int i;
    
    for(i=1;i<=x;i++)
    {
        p=x*i;
        int j = 7;
    }
    
    int j = (x > p)?x:p;
}
