#include<iostream>

x=5;
int main(){
	int x;
	int a,b,i;
	if(5>0)
	{
		x=2;
	}
	for(i = 0;  i < 10; i++){
		x=5;
	}
	while( x > 0 ){
		x-=1;
	}
	printf("x is positive");
}
