int main(){
	int a=3;
	int b=3;
	int x,i;
	for(i= 5;i<10;i++)
	{
		x = x+i;
	}
}
