int b;
//single line
int main()
{
/*
	multi
	line
*/
	int b;
	int a = 10;
	int c;
	int b;
	a=b+10;
	a-- ;
	int i;
	for(i=0;i<100;i++)
	{
		a=i;
	}
	while(i>0)
	{
		a=a-i;
	}
	if(i==0)
	{
		b=a;
	}
	else
	{
		a=b;
	}
	
}