int main()
{
	int a=0;
	int i;
	for(i=0;i<10;i++)
	{
		a=a-i;
	}
	int b=450;
	b=b+a;
}